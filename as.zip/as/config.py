class Config:
    DEBUG = True